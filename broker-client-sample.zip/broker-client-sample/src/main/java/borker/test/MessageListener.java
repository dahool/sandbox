package borker.test;

import java.io.Reader;
import java.lang.reflect.Type;
import java.util.concurrent.ExecutionException;

import org.springframework.messaging.converter.GsonMessageConverter;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

@Component
public class MessageListener extends StompSessionHandlerAdapter {

	private String topic = "/topic/token";
	
	private StompSession stompSession;

	public void connect() throws InterruptedException, ExecutionException {
		WebSocketClient socketClient = new StandardWebSocketClient();
		WebSocketStompClient stompClient = new WebSocketStompClient(socketClient);
		stompClient.setMessageConverter(new PayloadConverter());
		stompSession = stompClient.connect("ws://localhost:8080/broker", this).get();
	}
	
	@Override
	public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
		System.out.println("Connected");
		stompSession.subscribe(topic, this);
	}

	@Override
	public void handleFrame(StompHeaders headers, Object payload) {
		System.out.println("Received message " + payload.toString());
	}
	
	@Override
	public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload,
			Throwable exception) {
		exception.printStackTrace();
	}
	
	@Override
	public void handleTransportError(StompSession session, Throwable exception) {
		exception.printStackTrace();
	}
	
	private static final class PayloadConverter extends GsonMessageConverter {
		
		@Override
		protected Object fromJson(Reader reader, Type resolvedType) {
			return super.fromJson(reader, borker.test.UserActionAuthorization.class);
		}
		
		@Override
		protected Object fromJson(String payload, Type resolvedType) {
			return super.fromJson(payload, borker.test.UserActionAuthorization.class);
		}
	}

}
