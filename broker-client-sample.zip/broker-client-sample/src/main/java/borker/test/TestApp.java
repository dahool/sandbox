package borker.test;

import java.util.concurrent.ExecutionException;

public class TestApp {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		MessageListener listener = new MessageListener();
		listener.connect();
		
		Thread.sleep(240000);
		
	}
}
