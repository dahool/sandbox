package borker.test;

public class UserActionAuthorization {

	private String docType;
	
	private String docNumber;

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocNumber() {
		return docNumber;
	}

	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}

	@Override
	public String toString() {
		return "UserActionAuthorization [docType=" + docType + ", docNumber=" + docNumber + "]";
	}
	
}
